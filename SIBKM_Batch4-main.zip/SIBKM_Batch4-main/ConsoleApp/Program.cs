﻿//Identifier namespace
namespace ConsoleApp;

//Identifier Class
public class Program
{
    // Command / Variable & Methods
    public static void Main()
    {

        /*Queue<int> numbers = new Queue<int>();

        numbers.Enqueue(1);
        numbers.Enqueue(2);
        numbers.Enqueue(3);
        numbers.Enqueue(4);

        foreach (var number in numbers) {
            Console.WriteLine(number);
        }

        Stack<int> numberStack = new Stack<int>();
        numberStack.Push(1);
        numberStack.Push(2);
        numberStack.Push(3);
        numberStack.Push(4);

        foreach (var i in numberStack) {
            Console.WriteLine(i);
        }*/

        List<Employee<string>> employees = new List<Employee<string>>();

        Employee<string> herul = new Employee<string>();
        herul.Id = "123";
        herul.Name = "Herul";
        herul.Salary = 1000000;

        Employee<string> hanif = new Employee<string> {
            Id = "789",
            Name = "Hanif",
            Salary = 3000000
        };

        employees.Add(herul);
        employees.Add(new Employee<string> {
            Name = "Rifqi",
            Id = "456",
            Salary = 2000000
        });
        employees.Add(hanif);

        var whereMethod = employees.Where(x => x.Salary > 1500000);

        var whereQuery = from x in employees
                         where x.Salary > 1500000
                         select x;

        foreach (var employee in whereQuery) {
            Console.WriteLine(employee.Name);
        }
    }
}