﻿namespace ConsoleApp;
public class Employee<Type>
{
    public Type Id { get; set; }
    public string Name { get; set; }
    public int Salary { get; set; }

    public void Introduction()
    {
        Console.WriteLine("Id : " + Id);
        Console.WriteLine("Name : " + Name);
        Console.WriteLine("Salary : " + Salary);
    }
}
