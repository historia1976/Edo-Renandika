﻿namespace OOP;

public class Progam
{
    static void Main()
    {
        Person budi = new Person(30);
        budi.Name = "Budi";
        //budi.Age = 20;

        budi.Introduction();


        Person rizky = new Person(20);
        rizky.Name = "Rizky";
        //rizky.Age = 21;

        rizky.Introduction();

        Console.WriteLine();

        Employee violet = new Employee(25);
        violet.Name = "Violet";
        violet.Salary = 20000;
        violet.NIK = "138862";

        violet.Introduction();


        Manager rahmat = new Manager();
        rahmat.Name = "Rahmat";
        rahmat.Salary = 200000;
        rahmat.NIK = "322112";
        rahmat.Bonus = 100000;

        rahmat.Introduction();

        Manager ahmad = new Manager();
        ahmad.Name = "Ahmad";
        ahmad.Salary = 200000;
        ahmad.NIK = "322112";
        ahmad.Bonus = 100000;

        ahmad.Introduction();

        ICalculator2 calculator = new ImplementasiCalculator();
        Console.WriteLine(calculator.Penjumlahan(10, 10));
        Console.WriteLine(calculator.Pengurangan(10, 10));

        Console.WriteLine("Hello World");
    }
}