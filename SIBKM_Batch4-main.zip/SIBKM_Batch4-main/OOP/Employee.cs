﻿namespace OOP;
public class Employee : Person
{
    public int Salary { get; set; }
    public string NIK { get; set; }

    public Employee()
    {
        Console.WriteLine("Membuat Object Employee");
    }

    public Employee(int age) : base(age)
    {
        Console.WriteLine("Membuat Object Employee");
        Age = age;
    }

    public override void Introduction()
    {
        base.Introduction();
        Console.WriteLine("Salary : " + Salary);
        Console.WriteLine("NIK : " + NIK);
    }
}
