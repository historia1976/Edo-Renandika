﻿namespace OOP;
public abstract class ICalculator
{
    public int result;

    public abstract int Penjumlahan(int x, int y);

    public int Pengurangan(int x, int y)
    {
        result = x - y;
        return result;
    }
}
