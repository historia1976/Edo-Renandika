﻿namespace OOP;

internal class ImplementasiCalculator : ICalculator2
{
    public int Penjumlahan(int x, int y)
    {
        return x + y;
    }

    public int Pengurangan(int x, int y)
    {
        return x - y;
    }
}
