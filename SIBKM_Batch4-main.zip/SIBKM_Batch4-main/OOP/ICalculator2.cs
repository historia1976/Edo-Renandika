﻿namespace OOP;
public interface ICalculator2
{
    int Penjumlahan(int x, int y);
    int Pengurangan(int x, int y);
}
