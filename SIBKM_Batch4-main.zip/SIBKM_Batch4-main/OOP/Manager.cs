﻿namespace OOP;
public class Manager : Employee
{
    public int Bonus { get; set; }

    public override void Introduction()
    {
        base.Introduction();
        Console.WriteLine("Bonus : " + Bonus);
    }
}
