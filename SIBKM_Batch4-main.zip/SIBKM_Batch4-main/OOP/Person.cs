﻿namespace OOP;
public class Person
{
    public string Name { get; set; }
    public int Age { get; protected set; }

    public Person()
    {
        Console.WriteLine("Membuat sebuah object");
    }

    public Person(int age)
    {
        Console.WriteLine("Membuat sebuah object");
        Age = age;
    }

    public virtual void Introduction()
    {
        Console.WriteLine("Name : " + Name);
        Console.WriteLine("Age : " + Age);
    }
}
