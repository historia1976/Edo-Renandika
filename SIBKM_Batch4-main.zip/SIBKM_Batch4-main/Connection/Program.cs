﻿using Connection.Context;
using Connection.Controllers;
using Connection.Models;
using Connection.Repositories;
using Connection.Views;
using System.Data.SqlClient;
using System.Diagnostics.Metrics;

namespace Connection;

public class Program
{
    public static void Main()
    {
        var check = true;
        do {
            Console.Clear();
            Console.WriteLine("=======Database Connectivity=========");
            Console.WriteLine("1. Manage Table Region");
            Console.WriteLine("2. Manage Table Country");
            Console.WriteLine("3. Exit");
            Console.Write("Input: ");
            var input = Convert.ToInt16(Console.ReadLine());
            switch (input) {
                case 1:
                    Region();
                    break;
                case 2:
                    Country();
                    break;
                case 3:
                    check = false;
                    break;
                default:
                    Console.WriteLine("Input not found!");
                    Console.ReadKey();
                    check = true;
                    break;
            }
        } while (check);
    }

    public static void Region()
    {
        RegionController regionController = new RegionController(new RegionRepository(), new VRegion());
        var check = true;
        do {
            Console.Clear();
            Console.WriteLine("=======Table Region========");
            Console.WriteLine("1. Get All");
            Console.WriteLine("2. Get By Id");
            Console.WriteLine("3. Insert");
            Console.WriteLine("4. Update");
            Console.WriteLine("5. Delete");
            Console.WriteLine("6. Exit");
            Console.Write("Input: ");
            var input = Convert.ToInt16(Console.ReadLine());
            switch (input) {
                case 1:
                    Console.Clear();
                    regionController.GetAll();
                    Console.ReadKey();
                    break;
               
                case 2:
                    Console.Clear();
                    Console.WriteLine("=======Get Region By Id========");
                    Console.Write("Input Id: ");
                    var id = Convert.ToInt32(Console.ReadLine());
                    regionController.GetById(id);
                    Console.ReadKey();
                    break;
                    break;
                case 3:
                    Console.Clear();
                    Console.WriteLine("=======Insert Region========");
                    Console.Write("Input Name: ");
                    var name = Console.ReadLine();
                    regionController.Insert(new Region {
                        Name = name
                    });
                    Console.ReadKey();
                    break;
                // UPDATE : Region
                case 4:
                    Console.Clear();
                    Console.WriteLine("=======Update Region========");
                    Console.Write("Input Id: ");
                    var updateId = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Input New Name: ");
                    var newName = Console.ReadLine();
                    regionController.Update(new Region
                    {
                        Id = updateId,
                        Name = newName
                    });
                    Console.ReadKey();
                    break;
                    break;
                // DELETE : Region
                case 5:
                    Console.Clear();
                    Console.WriteLine("=======Delete Region========");
                    Console.Write("Input Id: ");
                    var deleteId = Convert.ToInt32(Console.ReadLine());
                    regionController.Delete(deleteId);
                    Console.ReadKey();
                    break;
                    break;
                case 6:
                    check = false;
                    break;
                default:
                    Console.WriteLine("Input not found!");
                    Console.ReadKey();
                    check = true;
                    break;
            }
        } while (check);
    }

    public static void Country()
    {

    }



    // GET BY ID : Region
    public static void GetByIdRegion(int id)
    {
        // Membuat instance SQL Server Connection
        var connection = MyContext.GetConnection();

        // Membuat instance SQL Command
        SqlCommand command = new SqlCommand();
        command.Connection = connection;
        command.CommandText = "Select * From region Where id = @id;";

        // Membuat instance SQL Parameter
        SqlParameter pId = new SqlParameter();
        pId.ParameterName = "@id";
        pId.SqlDbType = System.Data.SqlDbType.Int;
        pId.Value = id;
        command.Parameters.Add(pId);

        connection.Open();
        using SqlDataReader reader = command.ExecuteReader();
        if (reader.HasRows) {
            reader.Read();

            Console.WriteLine("Id : " + reader[0]);
            Console.WriteLine("Name : " + reader[1]);
        } else {
            Console.WriteLine($"id = {id} is not found!");
        }
        reader.Close();
        connection.Close();
    }

    // UPDATE : Region
    public static void UpdateRegion(Region region)
    {
        var connection = MyContext.GetConnection();
        connection.Open();

        SqlTransaction transaction = connection.BeginTransaction();

        try {
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandText = "Update region Set name = @name Where id = @id;";
            command.Transaction = transaction;

            SqlParameter pName = new SqlParameter();
            pName.ParameterName = "@name";
            pName.SqlDbType = System.Data.SqlDbType.VarChar;
            pName.Value = region.Name;
            command.Parameters.Add(pName);

            SqlParameter pId = new SqlParameter();
            pId.ParameterName = "@id";
            pId.SqlDbType = System.Data.SqlDbType.Int;
            pId.Value = region.Id;
            command.Parameters.Add(pId);

            int result = command.ExecuteNonQuery();
            if (result > 0) {
                Console.WriteLine("Update Success!");
            } else {
                Console.WriteLine($"id = {region.Id} is not found!");
            }

            transaction.Commit();
            connection.Close();

        } catch (Exception e) {
            Console.WriteLine("Something Wrong! : " + e.Message);
            try {
                transaction.Rollback();
            } catch (Exception exception) {
                Console.WriteLine(exception.Message);
            }
        }
    }

    // DELETE : Region
    public static void DeleteRegion(int id)
    {
        var connection = MyContext.GetConnection();
        connection.Open();

        SqlTransaction transaction = connection.BeginTransaction();

        try {
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandText = "Delete From region Where id = @id;";
            command.Transaction = transaction;

            SqlParameter pId = new SqlParameter();
            pId.ParameterName = "@id";
            pId.SqlDbType = System.Data.SqlDbType.Int;
            pId.Value = id;
            command.Parameters.Add(pId);

            int result = command.ExecuteNonQuery();
            if (result > 0) {
                Console.WriteLine("Delete Success!");
            } else {
                Console.WriteLine($"id = {id} is not found!");
            }

            transaction.Commit();
            connection.Close();

        } catch (Exception e) {
            Console.WriteLine("Something Wrong! : " + e.Message);
            try {
                transaction.Rollback();
            } catch (Exception exception) {
                Console.WriteLine(exception.Message);
            }
        }
    }




    // GET ALL : Country
    //GET BY ID : Country
    //INSERT : Country
    //UPDATE : Country
    //DELETE : Country
    public class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("\n==== Country App ====");
                Console.WriteLine("1. Get All Countries");
                Console.WriteLine("2. Get Country By Id");
                Console.WriteLine("3. Insert Country");
                Console.WriteLine("4. Update Country");
                Console.WriteLine("5. Delete Country");
                Console.WriteLine("0. Exit");

                Console.Write("\nEnter your choice: ");
                var input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        GetAllCountries();
                        break;
                    case "2":
                        Console.Write("Enter country id: ");
                        var id = Console.ReadLine();
                        GetCountryById(id);
                        break;
                    case "3":
                        Console.Write("Enter country name: ");
                        var name = Console.ReadLine();
                        Console.Write("Enter country region: ");
                        var region = Console.ReadLine();
                        InsertCountry(name, region);
                        break;
                    case "4":
                        Console.Write("Enter country id: ");
                        var updateId = Console.ReadLine();
                        Console.Write("Enter country name: ");
                        var updateName = Console.ReadLine();
                        Console.Write("Enter country region: ");
                        var updateRegion = Console.ReadLine();
                        UpdateCountry(updateId, updateName, updateRegion);
                        break;
                    case "5":
                        Console.Write("Enter country id: ");
                        var deleteId = Console.ReadLine();
                        DeleteCountry(deleteId);
                        break;
                    case "0":
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid choice!");
                        break;
                }
            }
        }

        static void GetAllCountries()
        {
            var country = CountryController.GetAll();
            foreach (var country in countries)
            {
                Console.WriteLine($"{country.Id}\t{country.Name}\t{country.Region}");
            }
        }

        static void GetCountryById(string id)
        {
            var country = CountryController.GetById(id);
            if (country != null)
            {
                Console.WriteLine($"{country.Id}\t{country.Name}\t{country.Region}");
            }
            else
            {
                Console.WriteLine($"Country with id '{id}' is not found");
            }
        }

        static void InsertCountry(string name, string region)
        {
            var country = new Country
            {
                Name = name,
                Region = region
            };
            if (CountryController.Insert(country))
            {
                Console.WriteLine("Insert success!");
            }
            else
            {
                Console.WriteLine("Insert failed!");
            }
        }

        static void UpdateCountry(string id, string name, string region)
        {
            var country = new Country
            {
                Id = id,
                Name = name,
                Region = region
            };
            if (CountryController.Update(country))
            {
                Console.WriteLine("Update success!");
            }
            else
            {
                Console.WriteLine($"Country with id '{id}' is not found");
            }
        }

        static void DeleteCountry(string id)
        {
            if (CountryController.Delete(id))
            {
                Console.WriteLine("Delete success!");
            }
            else
            {
                Console.WriteLine($"Country with id '{id}' is not found");
            }
        }
    }

}