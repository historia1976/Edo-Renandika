﻿using System;
using Connection.Models;
using Connection.Repositories;
using Connection.Repositories.Interfaces;
using Connection.Views;

namespace Connection.Controllers
{
    public class CountryController
    {
        private readonly ICountryRepository _countryRepository;
        private readonly VCountry _vCountry;

        public CountryController(ICountryRepository countryRepository, VCountry vCountry)
        {
            _countryRepository = countryRepository;
            _vCountry = vCountry;
        }

        // GET ALL
        public Country[] GetAll()
        {
            var countries = _countryRepository.GetAll();
            if (countries == null)
            {
                _vCountry.DataNotFound();
            }
            return countries;
        }

        // GET BY ID
        public Country GetById(string id)
        {
            var country = _countryRepository.GetById(id);
            if (country == null)
            {
                _vCountry.DataNotFound();
            }
            return country;
        }

        // INSERT
        public bool Insert(Country country)
        {
            var result = _countryRepository.Insert(country);
            if (result > 0)
            {
                _vCountry.Success("inserted");
                return true;
            }
            else
            {
                _vCountry.Failure("insert");
                return false;
            }
        }

        // UPDATE
        public bool Update(Country country)
        {
            var result = _countryRepository.Update(country);
            if (result > 0)
            {
                _vCountry.Success("updated");
                return true;
            }
            else
            {
                _vCountry.Failure("update");
                return false;
            }
        }

        // DELETE
        public bool Delete(string id)
        {
            var result = _countryRepository.Delete(id);
            if (result > 0)
            {
                _vCountry.Success("deleted");
                return true;
            }
            else
            {
                _vCountry.Failure("delete");
                return false;
            }
        }
    }