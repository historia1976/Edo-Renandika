﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Connection.Views
{
    public class VCountry
    {
        public void GetAll(Lis<Country> countries)
        {
            Console.WriteLine("=================");
            Console.WriteLine("ID\tName\tRegion ID");
            foreach (var country in countries)
            {
                Console.WriteLine($"{country.Id}\t{country.Name}\t{country.RegionId}");
            }
        }

        public void GetById(Country country)
        {
            if (country != null)
            {
                Console.WriteLine("=================");
                Console.WriteLine($"ID: {country.Id}");
                Console.WriteLine($"Name: {country.Name}");
                Console.WriteLine($"Region ID: {country.RegionId}");
            }
            else
            {
                DataNotFound();
            }
        }

        public void Insert(Country country, bool isSuccess)
        {
            if (isSuccess)
            {
                Success("inserted");
                GetById(country);
            }
            else
            {
                Failure("inserted");
            }
        }

        public void Update(Country country, bool isSuccess)
        {
            if (isSuccess)
            {
                Success("updated");
                GetById(country);
            }
            else
            {
                Failure("updated");
            }
        }

        public void Delete(bool isSuccess)
        {
            if (isSuccess)
            {
                Success("deleted");
            }
            else
            {
                Failure("deleted");
            }
        }

        public void Success(string message)
        {
            Console.WriteLine($"Data has been {message} successfully.");
        }

        public void Failure(string message)
        {
            Console.WriteLine($"Failed to {message} data.");
        }

        public void DataNotFound()
        {
            Console.WriteLine("Data not found!");
        }
    }
}
