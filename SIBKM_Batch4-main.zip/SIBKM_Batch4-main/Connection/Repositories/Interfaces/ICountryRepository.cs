﻿using Connection.Models;
using System.Collections.Generic;

namespace Connection.Repositories
{
    public interface ICountryRepository
    {
        List<Country> GetAll();
        Country GetById(string id);
        bool Insert(Country country);
        bool Update(Country country);
        bool Delete(string id);
    }
}
