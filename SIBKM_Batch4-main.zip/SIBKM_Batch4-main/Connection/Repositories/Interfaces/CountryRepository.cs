﻿using Connection.Models;
using System.Data.SqlClient;

public class CountryRepository
{
    private readonly string _connectionString;

    public CountryRepository(string connectionString)
    {
        _connectionString = connectionString;
    }

    public List<Country> GetAll()
    {
        using (var connection = new SqlConnection(_connectionString))
        {
            var command = new SqlCommand("SELECT * FROM Countries", connection);
            connection.Open();
            var reader = command.ExecuteReader();
            var countries = new List<Country>();
            while (reader.Read())
            {
                countries.Add(new Country
                {
                    Id = reader["id"].ToString(),
                    Name = reader["name"].ToString(),
                    Region = reader["region"].ToString()
                });
            }
            return countries;
        }
    }

    public Country GetById(string id)
    {
        using (var connection = new SqlConnection(_connectionString))
        {
            var command = new SqlCommand("SELECT * FROM Countries WHERE id=@id", connection);
            command.Parameters.AddWithValue("@id", id);
            connection.Open();
            var reader = command.ExecuteReader();
            if (reader.Read())
            {
                return new Country
                {
                    Id = reader["id"].ToString(),
                    Name = reader["name"].ToString(),
                    Region = reader["region"].ToString()
                };
            }
            else
            {
                return null;
            }
        }
    }

    public bool Insert(Country country)
    {
        using (var connection = new SqlConnection(_connectionString))
        {
            var command = new SqlCommand("INSERT INTO Countries (id, name, region) VALUES (@id, @name, @region)", connection);
            command.Parameters.AddWithValue("@id", country.Id);
            command.Parameters.AddWithValue("@name", country.Name);
            command.Parameters.AddWithValue("@region", country.Region);
            connection.Open();
            var result = command.ExecuteNonQuery();
            return result == 1;
        }
    }

    public bool Update(Country country)
    {
        using (var connection = new SqlConnection(_connectionString))
        {
            var command = new SqlCommand("UPDATE Countries SET name=@name, region=@region WHERE id=@id", connection);
            command.Parameters.AddWithValue("@id", country.Id);
            command.Parameters.AddWithValue("@name", country.Name);
            command.Parameters.AddWithValue("@region", country.Region);
            connection.Open();
            var result = command.ExecuteNonQuery();
            return result == 1;
        }
    }

    public bool Delete(string id)
    {
        using (var connection = new SqlConnection(_connectionString))
        {
            var command = new SqlCommand("DELETE FROM Countries WHERE id=@id", connection);
            command.Parameters.AddWithValue("@id", id);
            connection.Open();
            var result = command.ExecuteNonQuery();
            return result == 1;
        }
    }
}
